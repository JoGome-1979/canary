# Histórico de alterações

Este arquivo registra as alterações próprias deste repositório a partir da
implementação de loot premium. Não reproduz o histórico completo do projeto Canary.

## [Não lançado] — 2026-10-11

### Adicionado

- Bonificação por monstro configurável com `monster.lootpremium`, separada de
  `monster.loot`.
- Fluxo de cadastro Lua/C++ com `createLootPremium`, `addLootPremium`,
  `getLootPremium`, `loadLootPremium` e armazenamento em `lootPremiumItems`.
- Um único sorteio premium por morte, seguido de divisão entre os membros
  premium elegíveis da party, incluindo o líder. A elegibilidade também exige
  `canReceiveLoot()`; não há filtro adicional de distância, participação no
  combate ou experiência compartilhada.
- Reserva dos itens no corpo pelo GUID do destinatário, usando o atributo
  `premium_loot_owner`.
- Tipo `MESSAGE_LOOT_PREMIUM = 59`, registrado para Lua e enviado ao cliente
  compatível. Protocolos antigos usam a adaptação para mensagem de loot normal.
- Configuração premium no Mountain Troll do datapack OTServBR-Global, com
  platinum coins (ID 3035, até 2 unidades) e small health potion (ID 7876),
  ambos com `chance = 33000`.
- Documentação do sistema em `docs/systems/premium-loot.md` e referência dos
  métodos premium nos arquivos gerados da API Lua.
- Suíte Lua isolada com 15 cenários de cadastro, sorteio, divisão, itens com
  cargas, entradas repetidas, recipientes aninhados, falhas de criação/inserção
  e ausência dos métodos premium no executável antigo.

### Alterado

- Mensagens normal e premium montadas em `Creature::dropCorpse`, a partir dos
  itens efetivamente presentes no corpo, e enviadas por `Player::sendLootMessage`.
  O callback Lua fica responsável por sortear e criar os itens.
- A descrição normal exclui itens premium reservados. A descrição premium
  seleciona apenas os itens do GUID destinatário e não gera aviso para uma
  parte vazia.
- O aviso normal mantém o envio para a party; o premium é individual, evitando
  divulgar ou repetir a bonificação dos outros membros.
- Textos de loot com marcações de cor para título e nome do monstro. As descrições
  mantêm `{itemId|descrição}`, interpretado pelo cliente para aplicar as cores dos itens.
- README traduzido para português, com atalhos para o changelog, a documentação
  do loot premium e seu teste Lua isolado.

### Corrigido

- Verificação de acesso aos itens premium na movimentação, troca de posições,
  autoloot/autobank, uso direto, ações sobre alvos e Stow.
- Verificação de ancestrais e descendentes de recipientes para impedir a coleta
  ou o consumo de itens reservados a outro jogador, permitindo abrir o corpo
  compartilhado.
- Liberação da reserva após coleta bem-sucedida no inventário do destinatário,
  permitindo a troca normal do item depois da coleta.
- Preservação de cargas e entradas do mesmo ID com atributos diferentes no
  sorteio premium, além do cadastro e sorteio recursivo dos itens filhos.
- Leitura de filhos `Loot` com o acesso correspondente ao userdata compartilhado.
- Proteções Lua para ignorar a configuração e o sorteio premium quando o
  executável ainda não oferece os métodos necessários.

### Validação

- Os 15 cenários Lua passaram após a unificação do fluxo de mensagens.
- A suíte usa objetos simulados; não valida a compilação C++, o protocolo em
  execução nem o comportamento dentro do jogo.
- A compilação e os testes no jogo ficam a cargo do mantenedor. Não há resultado
  de teste em jogo registrado nesta entrada.
